# POS KASIR

Penggunaan repo ini hanya untuk tim kami.

Dilarang keras menggunakan program ini untuk kepentingan anda sendiri. 

UU ITE Berlaku